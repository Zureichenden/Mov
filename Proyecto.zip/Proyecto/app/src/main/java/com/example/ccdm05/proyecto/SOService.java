package com.example.ccdm05.proyecto;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import com.example.ccdm05.proyecto.SOAnswersResponse;
import retrofit2.*;
import retrofit2.http.Query;

public interface SOService {

    @GET("/answers?order=desc&sort=activity&site=stackoverflow")
    Call<SOAnswersResponse> getAnswers();

    @GET("/answers?order=desc&sort=activity&site=stackoverflow")
    Call<SOAnswersResponse> getAnswers(@Query("tagged") String tags);



}
